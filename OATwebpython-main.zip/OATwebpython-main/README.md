# oat python João Pedro e Arthur
nome: João Pedro Silvestre de Aragão, Arthur Craveiro de Araújo
curso: Sistemas da Informação, 5 Semestre.
